# 3MH TECHNOLOGIES | t.me/j49_c | t.me/bshshshkk | http://3mh.pages.dev
from __future__ import annotations
__version__ = "2.0.0"
__brand__ = "3MH TECHNOLOGIES"
__site__ = "http://3mh.pages.dev"
__support__ = "t.me/j49_c"
__channel__ = "t.me/bshshshkk"
__all__ = ["__version__", "__brand__", "__site__", "__support__", "__channel__"]
